const loader = () => {
    return <div className='app-spinner'></div>
}

export default loader;