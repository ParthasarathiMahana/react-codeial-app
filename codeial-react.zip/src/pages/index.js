import Setting from './Setting';
import UserProfile from './UserProfile';

export * from './Home';

export * from './Login';

export {Setting,UserProfile};